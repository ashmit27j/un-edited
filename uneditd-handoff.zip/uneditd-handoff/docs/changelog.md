# Changelog

Newest first. One line per change: date — what changed — why (if known). Update `current-config.md` alongside.

- 2026-10-09 — Added `design/motion/`: MOTION.md (all 11 animated areas written out with timings, easing, reduced-motion fallbacks and React Native notes), 10 filmstrips + raw frames, and a capture tool. No design changes.
- 2026-10-09 — Added all 16 stamp/cursor SVGs from the canvas (fixes the Brand stamp on sign-in, landing, tour and the As published stamp on Article).
- 2026-10-09 — Sign-out flow (mobile): You's "Sign out" button now opens a confirm sheet (SignOut + Ink) with an optional "Remove offline copies from this phone" checkbox (on by default). Confirming lands on You in guest state with a "Signed out" notice (YouSignedOut + Ink). You has a new `account` tweak: signedIn / guest / justSignedOut. Guest hides Storage and Sign out and shows "Sign in to sync". Not yet on the claude.ai canvas.
- 2026-10-09 — Exported the design canvas to local files and wrote this handoff. No design changes.
- 2026-10-08 — Pass 5: tour, accessibility settings, Components board, comment and consistency fixes (see `history/2026-10-08-design-doc.md`).
- 2026-10-07 — Pass 4: renamed to Un:edited, motto, Baskerville, stamps, onboarding review, landing rebuild.
- 2026-10-06 — Passes 1–3: core screens, onboarding, menus/states, web, landing. Expo app started.
