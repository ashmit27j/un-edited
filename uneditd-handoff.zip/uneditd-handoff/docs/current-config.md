# Un:edited — current configuration

_Merged from the design doc (passes 1–5, 2026-10-08) and the planning decisions log (2026-10-07). Written 2026-10-09._

**This is a snapshot of where things stand, not a spec.** Every line is Ashmit's to change. Each item carries a status:

- **current** — what the design and plans use today. Change it whenever you like; just update this file and `changelog.md`.
- **proposed** — suggested in planning, never confirmed.
- **open** — no answer yet.

When this file and the screen files disagree, ask Ashmit which one is right. Don't assume.

---

## 1. Product

| Topic | Setting | Status |
|---|---|---|
| What it is | A news reader that shows stories exactly as publishers wrote them, from outlets the reader picks. Newspaper feel. | current |
| Name | **Un:edited** (was "Un:editd" until 2026-10-07). The colon is two accent dots. | current |
| Motto | "Every story, as it was written." | current |
| One-liners | No AI — every word comes from the publisher. · No algorithm — only the outlets you choose. · No fee — free for everyone, always. | current |
| AI | Nothing the reader sees is written or rewritten by AI. AI behind the scenes (e.g. story grouping) is allowed if needed. | current |
| Price | Free for readers. Solo builder; keep paid services to a minimum. | current |
| Platforms | Android, iPhone, web — same features everywhere. | current |
| Distribution | Android: APK. Web: PWA. iPhone: the installable website (no App Store, no Apple developer fee). | current |
| Languages at launch | English, Hindi, Marathi — interface and source lists. | current |
| Handles / domain | Not chosen. Old handle was `uneditd`. | open |
| Funding story (for landing page) | Not written. | open |

## 2. Brand

| Topic | Setting | Status |
|---|---|---|
| Wordmark | "Un" + two-dot colon in accent, "edited" in ink. Baskerville Bold. | current |
| App icon | "Un" in Baskerville Bold, cropped at the right edge. Ink: coral #C8705F on #1C1A17. Paper: oxblood #A8372A on #F8F3EA with a thin rule border. | current |
| Voice | Plain, calm newspaper voice. Sentence case for buttons/links. Fictional outlets only in mockups. | current |
| Stamps | Round rubber-stamp marks (double ring, JetBrains Mono Bold ring text, Baskervville centre mark, slight tilt, ink texture, text outlined in SVG). Paper (oxblood) and Ink (coral), plain and "capped". Max one per screen. Never say "verified" or "fact-checked". | current |

**Stamp set (current):**

| Stamp | Ring text | Centre | Where |
|---|---|---|---|
| Brand | EVERY STORY · AS IT WAS WRITTEN · UN:EDITED · 2026 | Un: | Landing hero + footer, sign-in (stamp-down), end of tour |
| As published | AS PUBLISHED · WORD FOR WORD · NOT REWRITTEN | ¶ | Article image edge; web article right margin (hidden < 1080px) |
| Free | FREE FOR EVERYONE · ALWAYS · NO ADS · NO PAYWALL | ₹0 | Landing "Start" section |
| Read more (cursor) | READ MORE · READ MORE | ↗ | Web desktop: cursor over anything that opens a story |

Ideas, not made: Morning Edition stamp (`MORNING EDITION · PRINTED 6:00 IST`, "Nº 14"), All caught up stamp (`NEWS THAT ENDS · SEE YOU AT SIX`).

## 3. Design tokens (current)

| Token | Paper (light) | Ink (dark, low contrast) |
|---|---|---|
| bg | #F1EBE0 | #1E1C19 |
| surface | #F8F3EA | #262320 |
| ink | #1C1A17 | #C9C0B0 |
| muted | #6B645A | #8E8678 |
| rule | #DDD4C4 | #38332D |
| accent | #A8372A | #C8705F |
| accent-soft | #EBD5CC | #3A2924 |
| photo placeholder | #DCD2C1 | #2D2924 |

- **Fonts:** Baskervville (serif: headlines, body, wordmark) — stack `'Baskervville', Baskerville, 'Libre Baskerville', Georgia, serif`. Inter (UI, buttons, meta). JetBrains Mono (uppercase labels). Tiro Devanagari Hindi / Marathi + Mukta for Devanagari; set `lang` on all text.
- **Reader font option:** Serif / Sans (the `type` tweak on boards).
- **Type rules:** mono labels ≥ 11px; Inter meta ≥ 12px; body serif 16.5–18px at 1.55–1.6; mobile display 30px; weights 400/500 (700 for wordmark only); max one italic accent phrase per heading; numbered lists use the reading font; sentence case.
- **Shape:** square corners (sheets: 14px top radius; chips over images: round); thin rules, no shadows; 24px phone margin; 44px touch targets.
- **Scrollbars:** hidden on mobile; thin thumb-only on web.
- **Motion:** every animation has a reduced-motion fallback.

## 4. Structure and screens

**Navigation (current):** 4 tabs — Home · Feed · Library · You. Bottom on mobile, top on web. Active tab in accent.

| Area | Current behaviour | Status |
|---|---|---|
| Home | Newspaper front page: lead story, most-covered, a block per topic, Trending (opt-in), Papers & Reports, Continue reading, Outside your sources. Every section header has "See more". Search icon opens Search. | current |
| Home view | Comfortable (images) / Focused (text-led). Picked in onboarding, changeable in You › Reading. | current |
| Feed | "My Feed / Explore" toggle, category tabs (swipe left/right between sections), one story per screen with fade-out text, "You're all caught up" sheet at the end. | current |
| Per-story actions | Byline row: **Save, then ⋯**. | current (see §7) |
| ⋯ menu | Save to folder · Share link · More about [topic] · Not interested · Report a problem (opens a form: broken link, wrong image/credit, wrong grouping, other). | current |
| Article | Full screen, no tab bar. Image with Back (left) and vertical ⋯ (right); As published stamp; headline; text; "Continue on [source]"; Primary source block; Related stories. Bottom bar: previous/next source + Save. No source tabs. | current |
| Saving | "Save to" sheet to pick a folder; saved = filled accent bookmark. No Like. | current |
| Library | Folders ("Saved" + user folders, New folder); Recently viewed (last 5). In-app articles only. | current |
| Offline for folders | Per-folder "↓ Download / Remove" action on the folder screen. | current — conflicts, see §7 |
| Search | Field with X to close; Your sources / All sources. | current |
| You | Settings, Reading › Accessibility, About › Replay the tour, Storage. `account` tweak: signed in / guest / just signed out. | current |
| Sign out | You › Sign out opens a confirm sheet: "Sign out of Un:edited?", account stays intact, optional "Remove offline copies from this phone" (on by default), Sign out / Cancel. After: stay in the app as a guest, You shows a "Signed out" notice + "Sign in to sync". Mobile only so far. | current (added 2026-10-09) |
| Accessibility | Text size S–XL, line spacing Normal/Relaxed/Loose, match phone text size, higher contrast, underline links, reduce motion, live preview. | current |
| Guests | Can read without an account; Save and folders need sign-in (guest prompt with "Sign in"). | proposed |
| Loading / offline | Calm skeletons; offline screen pointing to saved articles. | current |

**Onboarding (current):** Welcome (animated wordmark, motto, one-liners) → 1 Language → 2 Reading (theme, font, home view, live preview) → 3 Topics (18 chips, min 1) → 4 Regions → 5 Sources "Choose who you trust" (min 3) → 6 Front page sections → "Getting your edition ready" → Sign in (Google / email / Not now) → first-run Tour. Steps have Back, "Step N of 6", Skip. Disabled buttons only where a minimum applies, with a line saying what's missing.

**Tour (current):** 8 steps + done — edition strip → lead story → Search → tab bar → Feed swipe → My Feed / Explore → Library → You → "You're all set" with stamp. Spotlight + scrim, hint card with accent top rule, Skip on every step, Back/Next, progress dashes.

**Web (current):** fluid, 1200px max, top nav. Home, Article, Feed, Library, You, Search, plus a first-visit Library sync hint. Desktop-only custom cursors (ink pointer; Read more stamp over story links).

**Landing page (current):** Hero → stats → 01 The idea → 02 Your sources → 03 Papers & reports → 04 Your day → 05 Questions → 06 Start → footer. Placeholders still in: `[ANSWER: how the project is funded]`, `[CONTACT EMAIL]`, store links.

## 5. Content and backend

| Topic | Setting | Status |
|---|---|---|
| Story grouping v1 | No AI: Postgres full-text similarity on headline + excerpt; match needs ≥ 2 shared strong words (names, places, numbers); 36-hour window; alias list; same language only; lean towards not merging. | proposed |
| Grouping upgrade | Small open-source model on own server (cross-language), only if v1 testing falls short. No hosted AI APIs. | proposed |
| Refresh | Fetch every 30 min with conditional requests. Home = Morning Edition built 06:00 IST, fixed for the day. Feed = live, with a "12 new stories" pill. Delete stored articles after 30 days unless saved. | proposed |
| Research | Papers & Reports as a Home block + Research category in Feed. Labels: Peer-reviewed / Preprint / Official report. Linked only when the article links them. | proposed |
| Stack | One Expo codebase (Android APK + web PWA), Supabase (DB + auth), scheduled fetch job (Supabase cron or GitHub Actions), Cloudflare Pages. | proposed |
| Sign-in | Google + email. No Sign in with Apple. | proposed |
| Android | Register as a verified developer early. | proposed |
| iPhone install guide | One-time Safari screen after onboarding: Share → Add to Home Screen. | proposed |

## 6. Build status

- Expo app started 2026-10-06 (Expo SDK 57, Expo Router, Supabase). Done: login-based routing at `/` and the web landing page.
  - `/`: signed in or guest → `/feed`; signed out on web → landing; signed out in app → `/welcome`.
  - Landing is pre-rendered in the HTML for search engines; a head script sends returning readers to `/feed`.
- That code (`uneditd-app.zip`) is **not in this folder** and still uses the old name, fonts and landing layout. It was built ahead of the design.

## 7. Where the history disagrees

These came up because older planning notes and later design passes say different things. The screens follow the newer version; none of these has been formally settled.

1. **Offline saving.** Planning said "no Download feature; saved articles are kept offline automatically (toggle in You › Storage)". Pass 5 added a per-folder Download / Remove action. Library and You › Storage copy still describe the automatic model. → **open**
2. **Card actions.** Planning said "only ⋯ in the byline, no separate Save icon". Pass 5 uses Save then ⋯. → screens use Save + ⋯
3. **Article top bar.** Planning said Save bookmark top-right on the image. Pass 5 moved Save to the bottom bar and put ⋯ top-right. → screens use ⋯ top-right
4. **Source switcher.** Planning said a source switcher under the headline. Pass 5 removed source tabs; switching is prev/next in the bottom bar. → screens use bottom bar
5. **List numbers.** Planning brand note said sans serif (Inter). Pass 5 changed them to the reading font (serif when Serif is on). → screens use reading font
6. **Travel-blog reference** (headline over image with dark fade, body as overlapping sheet) — the current Article doesn't do this. Treat as an idea, not a rule.

## 8. Open items (as of 2026-10-09)

- Pick the offline model (§7.1) and align Library, Folder and You › Storage copy.
- Fill landing placeholders: funding, contact email, store links.
- Web onboarding and a web tour.
- Web sign-out: WebYou has a Sign out button but no confirm dialog yet. Also decide: after sign-out, stay as a guest (current mobile design) or return to Welcome/landing?
- Handles and domain.
- Bring the Expo code up to date with the current design (name, motto, fonts, patterns).
- `Article-ptmb.dc.html` is Ashmit's experiment ("Article by" byline). Decide whether to merge it into Article or drop it.
