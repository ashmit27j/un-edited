# What's new — 2026-10-09 (update 3)

## 3. Motion spec, so Claude Code can see the animations
Claude Code can't play animations, and several (onboarding "printing", landing typing and phone demo) run on JS timers that don't show up in the markup. New folder `design/motion/`:
- **`MOTION.md`**: every animation written out with element, delay, duration, easing curve, loop and reduced-motion fallback, plus a CSS → React Native (Reanimated) translation table. Covers: Welcome wipe, edition printing sequence, sign-in stamp + card thud, Tour spotlight and swipe hint, Tour-done stamp, Feed caught-up papers, sheets, skeleton pulse, the full landing page, and web cursors.
- **`filmstrips/`**: 10 images, each a numbered grid of frames with timestamps (e.g. the stamp landing at 0.65 / 0.80 / 0.90 / 1.00s). Claude Code can open these.
- **`frames/`**: the individual full-size frames.
- **`tools/`**: a script to recapture filmstrips after design changes.
`CLAUDE.md` and the handoff prompt now tell Claude Code to use these instead of guessing.

---

# Update 2

## 1. Stamps and cursors are in
All 16 SVGs from the claude.ai canvas are now in `design/screens/assets/` (Brand, As published, Free × Paper/Ink × plain/capped, plus the 4 web cursors). The screens already pointed at these names, so they now render everywhere:
- **OB9 Sign in:** capped Brand stamp drops onto the **edition preview card** (the little newspaper card: wordmark, "Edition Nº 1" strip, photo, headline). The card itself is plain HTML in `OB9SignIn.dc.html` lines 28–35, and the stamp animation is in the same file.
- **Article / Web article:** As published stamp.
- **Landing, Tour end, Components, Stamps board:** Brand and Free stamps; web cursors.

For the app build: copy the SVGs into the Expo `assets/` folder and render them with `react-native-svg` (or as `<Image>` on web).

## 2. Sign-out flow (new, mobile)

| Board | What it shows |
|---|---|
| `You.dc.html` (updated) | "Sign out" button now links to the sheet. New `account` tweak: `signedIn` / `guest` / `justSignedOut`. Guest: dashed avatar, "Reading as a guest", "Sign in to sync" button; Storage section and Sign out hidden. |
| `SignOut.dc.html` + `SignOutDark` | Confirm sheet over You: "Sign out of Un:edited?", shows the signed-in email, explains the account and folders are kept, checkbox "Remove offline copies from this phone" (on by default), Sign out / Cancel. Reduced-motion fallback included. |
| `YouSignedOut.dc.html` + `YouSignedOutDark` | Where you land after signing out: You in guest state with a "Signed out" notice. |

Flow: **You → Sign out → sheet → Sign out → You (guest, notice)**, or **Cancel → You**.

These are suggestions, so change them freely. Things to decide:
- After signing out, should the reader stay in the app as a guest (as designed) or go back to Welcome / the landing page?
- Should "Remove offline copies" default to on?
- The web version (WebYou has the button, but there's no dialog yet).

Supabase side: `supabase.auth.signOut()`, then clear the local cache of saved articles if the box is ticked.

## Note
These changes are only in this folder. The claude.ai canvas doesn't have them yet.
